// eLua remote file system 

#ifndef __ELUA_RFS_H__
#define __ELUA_RFS_H__

#include "devman.h"

int remotefs_init( void );

#endif

