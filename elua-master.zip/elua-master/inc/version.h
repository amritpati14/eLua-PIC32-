// eLua version information

#ifndef __VERSION_H__
#define __VERSION_H__

#define     ELUA_VERSION          v0.9
#define     ELUA_STR_VERSION      "v0.9"

#endif
