// Keyboard handler

#ifndef __KB_H__
#define __KB_H__

void keyboard_install();
int keyboard_getch();

#endif
