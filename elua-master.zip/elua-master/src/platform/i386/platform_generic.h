// Included by platform_conf.h for platform customizations

#ifndef __PLATFORM_GENERIC_H__
#define __PLATFORM_GENERIC_H__

#define PLATFORM_HAS_SYSTIMER

#endif // #ifndef __PLATFORM_GENERIC_H__

