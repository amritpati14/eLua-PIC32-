// Stack size definitions

#ifndef __STACKS_H__
#define __STACKS_H__

#define  STACK_SIZE_TOTAL 32768

#endif

