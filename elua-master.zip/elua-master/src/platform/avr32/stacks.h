// Stack size definitions

#ifndef __STACKS_H__
#define __STACKS_H__

#define  STACK_SIZE       4096
#define  STACK_SIZE_TOTAL ( STACK_SIZE )

#endif
