-- eLua platform interface - name

data_en = 
{

  -- Title
  title = "eLua platform interface - name",

  -- Menu name
  menu_name = "name"

  -- Overview
  overview = [[
  ]],

  -- Data structures, constants and types
  structures = 
  {
    { text = [[ ]],
      name = "", 
      desc = [[ ]]
    },
  },

  -- Functions
  funcs = 
  {
    { sig = "void #functionname#( void )",
      desc = [[ ]],
      args = 
      {
        "$name$ - desc",
        "$name$ - desc",
      },
      ret = 
      {
         "",
         [[ ]],
      }, 
    },

  },

  -- Aux data
  auxdata = 
  {
    { title = "",
      desc = [[]]
    }
  }
}

data_pt = data_en
